import { d as defineEventHandler, a as readBody, g as getHashItemsFromCache, f as fetchAllPaginatedData } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'nitropack/dist/runtime/plugin';
import 'cron';
import 'ioredis';
import '@directus/sdk';
import '@primevue/core/base/style';
import '@primeuix/utils/object';
import '@primevue/forms/form/style';
import '@primeuix/styled';
import 'node:fs';
import 'node:url';
import 'node:path';

const list = defineEventHandler(async (event) => {
  console.log("\u89E6\u53D1paper_sections/list\u4E8B\u4EF6");
  const body = await readBody(event);
  const ids = body.ids;
  const data = await getHashItemsFromCache(
    "paper_sections",
    // Redis 中的 key
    ids,
    // 传入的 ID 列表
    () => fetchAllPaginatedData({
      collection: "paper_sections",
      fields: [
        "id",
        "sort_in_paper",
        "title",
        "description",
        "points_per_question",
        "question_type"
      ]
    })
    // 从数据库获取数据的函数
  );
  return data;
});

export { list as default };
//# sourceMappingURL=list.mjs.map
