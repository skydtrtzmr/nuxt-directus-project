import { d as defineEventHandler, r as redis, u as useRuntimeConfig } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'nitropack/dist/runtime/plugin';
import 'cron';
import 'ioredis';
import '@directus/sdk';
import '@primevue/core/base/style';
import '@primeuix/utils/object';
import '@primevue/forms/form/style';
import '@primeuix/styled';
import 'node:fs';
import 'node:url';
import 'node:path';

const {
  public: {
    directus: { url }
  },
  private: { redisHost, redisPort }
} = useRuntimeConfig();
console.log("\u83B7\u53D6\u5F53\u524D\u5B66\u751F");
const fetch_test_user = defineEventHandler(async (event) => {
  const user_email = await redis.lpop("student_user_email_list");
  console.log("user_email:", user_email);
  return user_email;
});

export { fetch_test_user as default };
//# sourceMappingURL=fetch_test_user.mjs.map
