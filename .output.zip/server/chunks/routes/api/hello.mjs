import { d as defineEventHandler } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'nitropack/dist/runtime/plugin';
import 'cron';
import 'ioredis';
import '@directus/sdk';
import '@primevue/core/base/style';
import '@primeuix/utils/object';
import '@primevue/forms/form/style';
import '@primeuix/styled';
import 'node:fs';
import 'node:url';
import 'node:path';

const hello = defineEventHandler((event) => {
  return {
    hello: "world"
  };
});

export { hello as default };
//# sourceMappingURL=hello.mjs.map
