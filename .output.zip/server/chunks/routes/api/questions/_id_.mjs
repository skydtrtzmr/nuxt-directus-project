import { d as defineEventHandler, b as getRouterParam, c as createError, e as getHashItemFromCache, f as fetchAllPaginatedData } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'nitropack/dist/runtime/plugin';
import 'cron';
import 'ioredis';
import '@directus/sdk';
import '@primevue/core/base/style';
import '@primeuix/utils/object';
import '@primevue/forms/form/style';
import '@primeuix/styled';
import 'node:fs';
import 'node:url';
import 'node:path';

const _id_ = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  if (!id) {
    throw createError({
      statusCode: 400,
      statusMessage: "\u7F3A\u5C11id\u53C2\u6570\uFF01Missing id parameter"
    });
  }
  const data = await getHashItemFromCache(
    "questions",
    // 这是 Redis 中存储数据的键
    id,
    // 题目的 id
    () => fetchAllPaginatedData({
      collection: "questions",
      fields: [
        "id",
        "stem",
        "type",
        "analysis",
        "q_mc_single.*",
        "q_mc_multi.*",
        "q_mc_binary.*",
        "q_mc_flexible.*",
        "question_group.*",
        "sort_in_group",
        "correct_ans_select_radio",
        "correct_ans_select_multiple_checkbox"
      ]
    })
    // 获取章节数据的函数
  );
  return data;
});

export { _id_ as default };
//# sourceMappingURL=_id_.mjs.map
