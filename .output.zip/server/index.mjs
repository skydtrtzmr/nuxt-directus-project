import process from 'node:process';globalThis._importMeta_={url:import.meta.url,env:process.env};import 'node:http';
import 'node:https';
import './chunks/_/nitro.mjs';
export { n as default } from './chunks/routes/api/paper_prototype_chapters/_id_.mjs';
import 'nitropack/dist/runtime/plugin';
import 'cron';
import 'ioredis';
import '@directus/sdk';
import '@primevue/core/base/style';
import '@primeuix/utils/object';
import '@primevue/forms/form/style';
import '@primeuix/styled';
import 'node:fs';
import 'node:url';
import 'node:path';
//# sourceMappingURL=index.mjs.map
