import{_ as e}from"./DlAUqK2U.js";import{r as t}from"./bGVraK0A.js";const o={};function s(r,n){return t(r.$slots,"default")}const _=e(o,[["render",s]]);export{_ as default};
